package com.gocartpay.model.enums;

public enum TransactionStatus {
    SUCCESS,
    FAILURE
}
