package com.gocartpay.model.enums;

public enum OrderStatus {
    PENDING,
    PROCESSED,
    ERROR,
    CANCELLED
}
