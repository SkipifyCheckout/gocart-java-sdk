package com.gocartpay.model.enums;

public enum SettlementType {
    Sale,
    AuthCapture
}
